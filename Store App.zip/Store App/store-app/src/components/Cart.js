import React from "react";
import OrderSummary from "./OrderSummary";

const Cart = ({ cart }) => {
  return (
    <div className="cart">
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <OrderSummary cart={cart} />
      )}
    </div>
  );
};

export default Cart;