import React from "react";

const OrderSummary = ({ cart }) => {
  const total = cart.reduce((acc, product) => acc + product.price, 0);

  return (
    <div className="order-summary">
      <ul>
        {cart.map((product, index) => (
          <li key={index}>
            {product.name} - ${product.price}
          </li>
        ))}
      </ul>
      <p>Total: ${total}</p>
      <button>Proceed to Checkout</button>
    </div>
  );
};

export default OrderSummary;