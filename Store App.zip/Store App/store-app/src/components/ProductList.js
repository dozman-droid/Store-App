import React from "react";
import ProductItem from "./ProductItem";

const products = [
  { id : 1, name: "Product 1", price: 20, image: "product 1.jpg" },
  { id: 2, name: "Product 2", price: 30, image: "product 2.jpg" },
  { id: 3, name: "Product 3", price: 50, image: "product 3.jpg" },
  { id: 4, name: "Product 4", price: 50, image: "product 4.jpg" },
];

const ProductList = ({ addToCart }) => {
  return (
    <div className="product-list">
      {products.map((product) => (
        <ProductItem key={product.id} product={product} addToCart={addToCart} />
      ))}
    </div>
  );
};

export default ProductList;